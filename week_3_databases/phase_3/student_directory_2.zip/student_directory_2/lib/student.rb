class Student
  attr_accessor :id, :name, :cohort_id
end